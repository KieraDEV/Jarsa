<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="theme-color" content="#4f23dc"/>
<meta name="og:title" content="Jarsa" />
<meta name="og:site_name" content="Jarsa"/>
<meta name="og:description" content="Bring fourth innovation and technology to your service, server or realm with Jarsa." />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="shortcut icon" href="favicon-32x32.png" type="image/png" />
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;700&display=swap" />
<link rel="stylesheet" href="/styles/smui-light.css" media="(prefers-color-scheme: light)" />
<link rel="stylesheet" href="/styles/smui-dark.css" media="screen and (prefers-color-scheme: dark)" />
<link rel="stylesheet" href="/styles/default.css" />

<title>Jarsa</title>
<link rel="modulepreload" href="/_app/start-a0bc9e5d.js">
<link rel="modulepreload" href="/_app/chunks/vendor-b04b43b2.js">
<link rel="modulepreload" href="/_app/chunks/singletons-12a22614.js">
<link rel="modulepreload" href="/_app/pages/__layout.svelte-c67b6423.js">
<link rel="modulepreload" href="/_app/chunks/MaterialIcon-9ee1d335.js">
<link rel="modulepreload" href="/_app/chunks/nav-603ff8f8.js">
<link rel="modulepreload" href="/_app/chunks/theme-1dbac9a9.js">
<link rel="modulepreload" href="/_app/pages/index.svelte-b14c20d8.js">
<link rel="modulepreload" href="/_app/chunks/Container-14bc427b.js">
<link rel="modulepreload" href="/_app/chunks/index-4bfee3f4.js">
<link rel="stylesheet" href="/_app/assets/start-61d1577b.css">
<link rel="stylesheet" href="/_app/assets/pages/index.svelte-e0207399.css">
<link rel="stylesheet" href="/_app/assets/index-ca6144de.css">
<script type="module">
			import { start } from "/_app/start-a0bc9e5d.js";
			start({
				target: document.querySelector("#svelte"),
				paths: {"base":"","assets":""},
				session: {},
				host: location.host,
				route: true,
				spa: false,
				trailing_slash: "never",
				hydrate: {
					status: 200,
					error: null,
					nodes: [
						import("/_app/pages/__layout.svelte-c67b6423.js"),
						import("/_app/pages/index.svelte-b14c20d8.js")
					],
					page: {
						host: location.host, // Yes
						path: "\u002F",
						query: new URLSearchParams(""),
						params: {}
					}
				}
			});
		</script>
</head>
<body>
<div id="svelte">
<div><aside class="mdc-drawer mdc-drawer--modal"><div class="mdc-drawer__header"><h1 class="mdc-drawer__title">Jarsa
</h1>
<h2 class="mdc-drawer__subtitle">Development on a simplistic, modern and reliable platform.
</h2>
</div>
<div class="mdc-drawer__content"><nav class="mdc-deprecated-list" role="list">
<a href="#" class="mdc-deprecated-list-item mdc-deprecated-list-item--activated" style="" aria-current="page" tabindex="-1"><span class="mdc-deprecated-list-item__ripple"></span><span class="material-icons mdc-deprecated-list-item__graphic" aria-hidden="true"><button class="mdc-icon-button" style=""><svg class="mdc-icon-button__icon" aria-hidden="true" focusable="false" tabindex="-1" viewBox="0 0 24 24" style=""><path fill="currentColor" d="M10,20V14H14V20H19V12H22L12,3L2,12H5V20H10Z"></path></svg>
</button>
</span>
<span class="mdc-deprecated-list-item__text">Home</span>
</a>
<span class="mdc-deprecated-list-item mdc-deprecated-list-item--disabled smui-menu-item--non-interactive" style="" tabindex="-1"><span class="material-icons mdc-deprecated-list-item__graphic" aria-hidden="true"><button class="mdc-icon-button" style=""><svg class="mdc-icon-button__icon" aria-hidden="true" focusable="false" tabindex="-1" viewBox="0 0 24 24" style=""><path fill="currentColor" d="M13,3V9H21V3M13,21H21V11H13M3,21H11V15H3M3,13H11V3H3V13Z"></path></svg>
</button>
</span>
<span class="mdc-deprecated-list-item__text">Dashboard</span>
</span>
<a href="#" class="mdc-deprecated-list-item" style="" tabindex="-1"><span class="mdc-deprecated-list-item__ripple"></span><span class="material-icons mdc-deprecated-list-item__graphic" aria-hidden="true"><button class="mdc-icon-button" style=""><svg class="mdc-icon-button__icon" aria-hidden="true" focusable="false" tabindex="-1" viewBox="0 0 24 24" style=""><path fill="currentColor" d="M15.07,11.25L14.17,12.17C13.45,12.89 13,13.5 13,15H11V14.5C11,13.39 11.45,12.39 12.17,11.67L13.41,10.41C13.78,10.05 14,9.55 14,9C14,7.89 13.1,7 12,7A2,2 0 0,0 10,9H8A4,4 0 0,1 12,5A4,4 0 0,1 16,9C16,9.88 15.64,10.67 15.07,11.25M13,19H11V17H13M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12C22,6.47 17.5,2 12,2Z"></path></svg>
</button>
</span>
<span class="mdc-deprecated-list-item__text">Support</span>
</a>
<a href="https://discord.gg/58DpEJxaHq" class="mdc-deprecated-list-item" style="" tabindex="-1" target="_blank"><span class="mdc-deprecated-list-item__ripple"></span><span class="material-icons mdc-deprecated-list-item__graphic" aria-hidden="true"><button class="mdc-icon-button" style=""><svg class="mdc-icon-button__icon" aria-hidden="true" focusable="false" tabindex="-1" viewBox="0 0 24 24" style=""><path fill="currentColor" d="M22,24L16.75,19L17.38,21H4.5A2.5,2.5 0 0,1 2,18.5V3.5A2.5,2.5 0 0,1 4.5,1H19.5A2.5,2.5 0 0,1 22,3.5V24M12,6.8C9.32,6.8 7.44,7.95 7.44,7.95C8.47,7.03 10.27,6.5 10.27,6.5L10.1,6.33C8.41,6.36 6.88,7.53 6.88,7.53C5.16,11.12 5.27,14.22 5.27,14.22C6.67,16.03 8.75,15.9 8.75,15.9L9.46,15C8.21,14.73 7.42,13.62 7.42,13.62C7.42,13.62 9.3,14.9 12,14.9C14.7,14.9 16.58,13.62 16.58,13.62C16.58,13.62 15.79,14.73 14.54,15L15.25,15.9C15.25,15.9 17.33,16.03 18.73,14.22C18.73,14.22 18.84,11.12 17.12,7.53C17.12,7.53 15.59,6.36 13.9,6.33L13.73,6.5C13.73,6.5 15.53,7.03 16.56,7.95C16.56,7.95 14.68,6.8 12,6.8M9.93,10.59C10.58,10.59 11.11,11.16 11.1,11.86C11.1,12.55 10.58,13.13 9.93,13.13C9.29,13.13 8.77,12.55 8.77,11.86C8.77,11.16 9.28,10.59 9.93,10.59M14.1,10.59C14.75,10.59 15.27,11.16 15.27,11.86C15.27,12.55 14.75,13.13 14.1,13.13C13.46,13.13 12.94,12.55 12.94,11.86C12.94,11.16 13.45,10.59 14.1,10.59Z"></path></svg>
</button>
</span>
<span class="mdc-deprecated-list-item__text">Community</span>
</a>
</nav>
</div>
</aside>
<div class="mdc-drawer-scrim">
</div></div>
<header class="nav-default mdc-top-app-bar mdc-top-app-bar--fixed" style="transition: background-color 500ms ease-in-out;"><div class="mdc-top-app-bar__row"><section class="mdc-top-app-bar__section mdc-top-app-bar__section--align-start"><button class="material-icons mdc-icon-button mdc-top-app-bar__navigation-icon" style=""><svg class="mdc-icon-button__icon" aria-hidden="true" focusable="false" tabindex="-1" viewBox="0 0 24 24" style=""><path fill="currentColor" d="M3,6H21V8H3V6M3,11H21V13H3V11M3,16H21V18H3V16Z"></path></svg></button>
<span class="mdc-top-app-bar__title">Jarsa</span>
</section>
<section class="mdc-top-app-bar__section mdc-top-app-bar__section--align-end" role="toolbar">
<a href="https://discord.gg/58DpEJxaHq" class="material-icons mdc-icon-button mdc-top-app-bar__action-item" style=""><svg class="mdc-icon-button__icon" aria-hidden="true" focusable="false" tabindex="-1" viewBox="0 0 24 24" style=""><path fill="currentColor" d="M15.07,11.25L14.17,12.17C13.45,12.89 13,13.5 13,15H11V14.5C11,13.39 11.45,12.39 12.17,11.67L13.41,10.41C13.78,10.05 14,9.55 14,9C14,7.89 13.1,7 12,7A2,2 0 0,0 10,9H8A4,4 0 0,1 12,5A4,4 0 0,1 16,9C16,9.88 15.64,10.67 15.07,11.25M13,19H11V17H13M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12C22,6.47 17.5,2 12,2Z"></path></svg></a>
<div class="mdc-tooltip" style="" role="tooltip" aria-hidden="true" id="SMUI-tooltip-0"><div class="mdc-tooltip__surface mdc-tooltip__surface-animation" style="">Support</div>
</div>
<a href="https://discord.gg/58DpEJxaHq"" class="mdc-icon-button mdc-top-app-bar__action-item" style="" target="_blank"><svg class="mdc-icon-button__icon" aria-hidden="true" focusable="false" tabindex="-1" viewBox="0 0 24 24" style=""><path fill="currentColor" d="M22,24L16.75,19L17.38,21H4.5A2.5,2.5 0 0,1 2,18.5V3.5A2.5,2.5 0 0,1 4.5,1H19.5A2.5,2.5 0 0,1 22,3.5V24M12,6.8C9.32,6.8 7.44,7.95 7.44,7.95C8.47,7.03 10.27,6.5 10.27,6.5L10.1,6.33C8.41,6.36 6.88,7.53 6.88,7.53C5.16,11.12 5.27,14.22 5.27,14.22C6.67,16.03 8.75,15.9 8.75,15.9L9.46,15C8.21,14.73 7.42,13.62 7.42,13.62C7.42,13.62 9.3,14.9 12,14.9C14.7,14.9 16.58,13.62 16.58,13.62C16.58,13.62 15.79,14.73 14.54,15L15.25,15.9C15.25,15.9 17.33,16.03 18.73,14.22C18.73,14.22 18.84,11.12 17.12,7.53C17.12,7.53 15.59,6.36 13.9,6.33L13.73,6.5C13.73,6.5 15.53,7.03 16.56,7.95C16.56,7.95 14.68,6.8 12,6.8M9.93,10.59C10.58,10.59 11.11,11.16 11.1,11.86C11.1,12.55 10.58,13.13 9.93,13.13C9.29,13.13 8.77,12.55 8.77,11.86C8.77,11.16 9.28,10.59 9.93,10.59M14.1,10.59C14.75,10.59 15.27,11.16 15.27,11.86C15.27,12.55 14.75,13.13 14.1,13.13C13.46,13.13 12.94,12.55 12.94,11.86C12.94,11.16 13.45,10.59 14.1,10.59Z"></path></svg></a>
<div class="mdc-tooltip" style="" role="tooltip" aria-hidden="true" id="SMUI-tooltip-1"><div class="mdc-tooltip__surface mdc-tooltip__surface-animation" style="">Community</div>
</div>
</section>
</div>
</header>
<main style="padding-top: 90px; padding-bottom: 40px; text-align: center; overflow: hidden;">
<div class="container" style="max-width: 70%;padding-bottom: 100px;"><div class="grid svelte-km144g"><div class="feat-desc svelte-km144g"><h2 class="text-main svelte-km144g"><strong class="svelte-km144g">Show your True Developer Power with Jarsa.</strong></h2>
<h4 class="text-main svelte-km144g">With action-packed text editor, templates, tutorials, 
experience, while keeping things simple and easy to use.
</h4>
<div class="svelte-km144g"><a href="https://discord.gg/58DpEJxaHq"" class="mdc-button mdc-button--raised" style="" target="_blank"><div class="mdc-button__ripple"></div>
<svg class="mdc-button__icon" aria-hidden="true" focusable="false" tabindex="-1" viewBox="0 0 24 24" style=""><path fill="currentColor" d="M22,24L16.75,19L17.38,21H4.5A2.5,2.5 0 0,1 2,18.5V3.5A2.5,2.5 0 0,1 4.5,1H19.5A2.5,2.5 0 0,1 22,3.5V24M12,6.8C9.32,6.8 7.44,7.95 7.44,7.95C8.47,7.03 10.27,6.5 10.27,6.5L10.1,6.33C8.41,6.36 6.88,7.53 6.88,7.53C5.16,11.12 5.27,14.22 5.27,14.22C6.67,16.03 8.75,15.9 8.75,15.9L9.46,15C8.21,14.73 7.42,13.62 7.42,13.62C7.42,13.62 9.3,14.9 12,14.9C14.7,14.9 16.58,13.62 16.58,13.62C16.58,13.62 15.79,14.73 14.54,15L15.25,15.9C15.25,15.9 17.33,16.03 18.73,14.22C18.73,14.22 18.84,11.12 17.12,7.53C17.12,7.53 15.59,6.36 13.9,6.33L13.73,6.5C13.73,6.5 15.53,7.03 16.56,7.95C16.56,7.95 14.68,6.8 12,6.8M9.93,10.59C10.58,10.59 11.11,11.16 11.1,11.86C11.1,12.55 10.58,13.13 9.93,13.13C9.29,13.13 8.77,12.55 8.77,11.86C8.77,11.16 9.28,10.59 9.93,10.59M14.1,10.59C14.75,10.59 15.27,11.16 15.27,11.86C15.27,12.55 14.75,13.13 14.1,13.13C13.46,13.13 12.94,12.55 12.94,11.86C12.94,11.16 13.45,10.59 14.1,10.59Z"></path></svg>
<span class="mdc-button__label">Support/span></a>
<div class="mdc-tooltip" style="" role="tooltip" aria-hidden="true" id="SMUI-tooltip-2"><div class="mdc-tooltip__surface mdc-tooltip__surface-animation" style="">This will allow you to create a ticket with a representative.</div>
</div>
<a href="https://discord.gg/58DpEJxaHq" class="mdc-button mdc-button--raised" style=""><div class="mdc-button__ripple"></div>
<i class="material-icons mdc-button__icon" aria-hidden="true" style="margin-left: 0px; margin-right: 4px;"><svg class="mdc-button__icon" aria-hidden="true" focusable="false" tabindex="-1" viewBox="0 0 24 24" style=""><path fill="currentColor" d="M15.07,11.25L14.17,12.17C13.45,12.89 13,13.5 13,15H11V14.5C11,13.39 11.45,12.39 12.17,11.67L13.41,10.41C13.78,10.05 14,9.55 14,9C14,7.89 13.1,7 12,7A2,2 0 0,0 10,9H8A4,4 0 0,1 12,5A4,4 0 0,1 16,9C16,9.88 15.64,10.67 15.07,11.25M13,19H11V17H13M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12C22,6.47 17.5,2 12,2Z"></path></svg></i>
<span class="mdc-button__label">Community</span></a></div></div>
<div class="svelte-km144g">
<div class="mdc-dialog" role="alertdialog" aria-modal="true"><div class="mdc-dialog__container"><div class="mdc-dialog__surface" role="alertdialog" aria-modal="true" style="width: 80vw; max-width: calc(100vw - 32px); box-shadow: none; background-color: transparent; object-fit: contain;"><div class="flex expanded-image-container svelte-13z0e6a" tabindex="0"><img class="expanded-image svelte-13z0e6a" src="/img/dark/role-menus.png" alt="Reactive" style="border-radius: 4px;"></div>
</div></div>
<div class="mdc-dialog__scrim"></div></div>
<div class="expandable-image svelte-13z0e6a" tabindex="0"><div style="cursor: pointer;"><div class="flex svelte-13z0e6a"><img src="jarsa.png" alt="Reactive" style="max-width: 100%; border-radius: 4px;"></div></div></div>
<div class="mdc-tooltip" style="" role="tooltip" aria-hidden="true" id="SMUI-tooltip-3"><div class="mdc-tooltip__surface mdc-tooltip__surface-animation" style="">View the Glory</div>
</div></div></div></div>
<div class="container" style="max-width: 70%;padding-bottom: 80px;"><div class="grid feat-desc svelte-km144g"><div class="paper-default smui-paper smui-paper--elevation-z1 smui-paper--rounded" style="transition: background-color 500ms ease-in-out, box-shadow 500ms ease-in-out;"><h5 class="smui-paper__title"><span><svg class="" aria-hidden="true" focusable="false" tabindex="-1" viewBox="0 0 24 24" style="height: 29px; position: relative; top: 6px;"><path fill="currentColor" d="M6.92,5H5L14,14L15,13.06M19.96,19.12L19.12,19.96C18.73,20.35 18.1,20.35 17.71,19.96L14.59,16.84L11.91,19.5L10.5,18.09L11.92,16.67L3,7.75V3H7.75L16.67,11.92L18.09,10.5L19.5,11.91L16.83,14.58L19.95,17.7C20.35,18.1 20.35,18.73 19.96,19.12Z"></path></svg>
Efficient</span>
</h5>
</div>
<div class="paper-default smui-paper smui-paper--elevation-z1 smui-paper--rounded" style="transition: background-color 500ms ease-in-out, box-shadow 500ms ease-in-out;"><h5 class="smui-paper__title"><span><svg class="" aria-hidden="true" focusable="false" tabindex="-1" viewBox="0 0 24 24" style="height: 29px; position: relative; top: 6px;"><path fill="currentColor" d="M16 9C22 9 22 13 22 13V15H16V13C16 13 16 11.31 14.85 9.8C14.68 9.57 14.47 9.35 14.25 9.14C14.77 9.06 15.34 9 16 9M2 13C2 13 2 9 8 9S14 13 14 13V15H2V13M9 17V19H15V17L18 20L15 23V21H9V23L6 20L9 17M8 1C6.34 1 5 2.34 5 4S6.34 7 8 7 11 5.66 11 4 9.66 1 8 1M16 1C14.34 1 13 2.34 13 4S14.34 7 16 7 19 5.66 19 4 17.66 1 16 1Z"></path></svg>
Team Supported</span>
</h5>
</div>
<div class="paper-default smui-paper smui-paper--elevation-z1 smui-paper--rounded" style="transition: background-color 500ms ease-in-out, box-shadow 500ms ease-in-out;"><h5 class="smui-paper__title"><span><svg class="" aria-hidden="true" focusable="false" tabindex="-1" viewBox="0 0 24 24" style="height: 29px; position: relative; top: 6px;"><path fill="currentColor" d="M9 17H7V10H9V17M13 17H11V7H13V17M17 17H15V13H17V17M19 19H5V5H19V19.1M19 3H5C3.9 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19V5C21 3.9 20.1 3 19 3Z"></path></svg>
Custom</span>
</h5></main>
</div>
<script src="/devtools-detect.js" defer></script>
<script>
            window.addEventListener("devtoolschange", event => {
                // Temporarily disable this message entirely.
                return;
                if (!event.detail.isOpen) return;
                console.log(
                    "%cHold up!",
                    "color: red; font-size: 500%; text-shadow: 2px 0 0 #000000, -2px 0 0 #000000, 0 2px 0 #000000, 0 -2px 0 #000000, 1px 1px #000000, -1px -1px 0 #000000, 1px -1px 0 #000000, -1px 1px 0 #000000; font-weight: bold;"
                );
                console.log(
                    "%cThis is a browser feature intended for developers.",
                    "font-size: 200%; font-weight: bold;"
                );
                console.log(
                    "%cIf you paste anything here you will be violating Jarsa's ToS",
                    "font-size: 300%; font-weight: bold; color: red;"
                );
                console.log(
                    "%cThis is not a way to receive free packages.",
                    "font-size: 300%; font-weight: bold; color: blue;"
                );
                console.log(
                    "%cIf you don't know what you're doing, you should probably turn back now.",
                    "font-size: 200%; font-weight: bold;"
                );
            });
        </script>
</body>
</html>
